class MetadataMock {
  update () {
    return Promise.resolve(null);
  }
  fetch () {
    return Promise.resolve(null);
  }
}

module.exports = MetadataMock;
